const express = require('express');
const { getCryptoStats, calculateDeviation,fetchAndSaveData } = require('../controllers/cryptoController');
const cron=require('node-cron');
const router = express.Router();


router.get('/', async (req, res) => {
    cron.schedule('0 0 */2 * * *', async () => {
        console.log('Running cron job to update cryptocurrency data');
        try {
            await fetchAndSaveData();
            console.log('Data updated successfully by cron job');
        } catch (error) {
            console.error('Error in cron job:', error.message);
        }
    });
    res.send('Cron job scheduled to run every 2 hours.');
});
router.get('/stats/:coin', getCryptoStats);


router.get('/deviation/:coin', calculateDeviation);

module.exports = router;
