const Info = require('../models/Info'); 
const axios = require('axios');
const { std } = require('mathjs');


const fetchAndSaveData = async () => {
    try {
        const response = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
            params: {
                vs_currency: 'usd',
                ids: 'bitcoin,ethereum,matic-network',
            },
        });

        for (const cryptocurrency of response.data) {
            const { name, current_price, market_cap, price_change_percentage_24h, last_updated } = cryptocurrency;

            
            const info = await Info.findOne({ name });

            if (info) {
                
                info.current_price.push(current_price); 
                info.market_cap = market_cap;
                info.price_change_percentage_24h = price_change_percentage_24h;
                info.last_updated = last_updated;
                await info.save(); 
            } else {
                // Create new record if it doesn't exist
                const newInfo = new Info({
                    name,
                    current_price: [current_price], 
                    market_cap,
                    price_change_percentage_24h,
                    last_updated,
                });
                await newInfo.save(); 
            }
        }

        console.log('Data saved/updated in MongoDB successfully');

    } catch (error) {
        console.error('Error fetching or saving cryptocurrency data:', error.message);
    }
};


// Get the most recent cryptocurrency stats
const getCryptoStats = async (req, res) => {
    try {
        const coinName = req.params.coin.trim();
        const values = await Info.findOne({
            name: { $regex: new RegExp('^' + coinName + '$', 'i') },
        });

        if (!values) {
            return res.status(404).json({ error: 'Cryptocurrency not found' });
        }

        const { current_price, market_cap, price_change_percentage_24h } = values;
        let array=[];
        array.push(current_price[current_price.length - 1]);
        res.json({
            price: array,
            market_cap,
            price_change_percentage_24h,
        });
    } catch (error) {
        console.error('Error fetching coin stats:', error.message);
        res.status(500).json({ error: 'Internal server error' });
    }
};

// Calculate the standard deviation of cryptocurrency prices
const calculateDeviation = async (req, res) => {
    try {
        const coinName = req.params.coin.trim();
        const values = await Info.find({ name: { $regex: new RegExp('^' + coinName + '$', 'i') } })
            .sort({ last_updated: -1 })
            .limit(100);

        if (!values || values.length === 0) {
            return res.status(404).json({ error: 'Cryptocurrency not found' });
        }

        const currentPrices = values.map(entry => entry.current_price);
        console.log(currentPrices);
        const numEntries = Math.min(currentPrices.length, 100);
        const deviation = std(currentPrices.slice(0, numEntries));

        res.json({ deviation });
    } catch (error) {
        console.error('Error calculating coin deviation:', error.message);
        res.status(500).json({ error: 'Internal server error' });
    }
};

module.exports = { fetchAndSaveData, getCryptoStats, calculateDeviation };
