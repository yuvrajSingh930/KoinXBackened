const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const statsRouter = require('./routes/cryptoRoutes'); // Import the stats routes file
const connectDB = require('./config/db'); // Import the database connection function

// Load environment variables
dotenv.config();

// Set up the Express app
const app = express();
app.use(cors());  // Enable cross-origin requests (if needed)
app.use(express.json());  // Parse JSON bodies

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("Connected to MongoDB"))
    .catch(err => console.error("Failed to connect to MongoDB", err));

// Use the router for the stats-related endpoints
app.use('/', statsRouter); 
// app.js

const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
