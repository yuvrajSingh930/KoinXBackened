const mongoose = require('mongoose');

const infoSchema = new mongoose.Schema({
    name: { type: String, required: true },
    current_price: [Number],
    market_cap: Number,
    price_change_percentage_24h: Number,
    last_updated: Date,
});

const Info = mongoose.model('Info', infoSchema);

module.exports = Info;
